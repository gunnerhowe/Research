"""Generate paper/numbers.tex from results/*.json. Every number in the paper's
prose or figures caption comes from here (house rule: no hand-typed result
numbers; macro names contain no digits). verify_regen.py checks byte-identity."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
RES = ROOT / "results"
OUT = ROOT / "paper" / "numbers.tex"
M = {}


def macro(name, value):
    assert not any(ch.isdigit() for ch in name), f"digit in macro name: {name}"
    M[name] = value


def pct(x, nd=1):
    return f"{100 * x:.{nd}f}\\%"


def pts(x, nd=1):
    return f"{100 * x:.{nd}f}"


def num(x, nd=2):
    return f"{x:.{nd}f}"


def g(x):
    s = f"{x:g}"
    return s


def load(name):
    with open(RES / name) as f:
        return json.load(f)


BASELINE_LABELS = {"ou": "unconditioned OU", "mesu": "MESU", "ewc_best": "EWC",
                   "benna_fusi": "Benna--Fusi", "replay": "replay", "none": "naive"}

e0 = load("exp0_falsifier.json")
e1 = load("exp1_isolation.json")
e2 = load("exp2_bss2.json")
e3 = load("exp3_baselines.json")
e4 = load("exp4_modality.json")

# ------------------------------------------------------------------ E0 GATE F
macro("NumSeeds", str(len(e0["config"]["seeds"])))
macro("NumSigma", str(len(e0["config"]["sigmas"])))
iu = e0["methods"]["doob"]["inverted_u"]
macro("GateFSigStar", g(iu["sigma_star"]))
macro("GateFLiftPts", pts(iu["lift_over_zero"]))
macro("GateFPzero", num(iu["p_peak_gt_zero"], 3))
macro("GateFPhi", num(iu["p_peak_gt_hi"], 3))
macro("GateFZeroPct", pct(iu["ret_at_zero"]))
macro("GateFPeakPct", pct(iu["ret_at_peak"]))
ctrl_mono = [e0["methods"][m]["monotone_dec_frac"] for m in ("ou", "ewc", "mesu", "none")]
macro("ControlMonoWorst", num(min(ctrl_mono), 2))

# ------------------------------------------------------------------ E1 isolation
macro("KappaZeroLiftPts", pts(e1["kappa_scan"]["0.0"]["inverted_u"]["lift_over_zero"]))
macro("KappaOneLiftPts", pts(e1["kappa_scan"]["1.0"]["inverted_u"]["lift_over_zero"]))

# ------------------------------------------------------------------ E2 BSS-2
b_iu = e2["device_faithful"]["inverted_u"]
macro("BssLiftPts", pts(b_iu["lift_over_zero"]))
macro("BssSigStar", g(b_iu["sigma_star"]))
macro("BssSurviveWord", "survives" if b_iu["inverted_u"] else "does not survive")

# ------------------------------------------------------------------ E3 baselines
Mm = e3["methods"]
macro("DoobStarRetPct", pct(Mm["doob*"]["retention_mean"]))
macro("MesuRetPct", pct(Mm["mesu"]["retention_mean"]))
macro("EwcRetPct", pct(Mm["ewc_best"]["retention_mean"]))
macro("OuRetPct", pct(Mm["ou"]["retention_mean"]))
macro("BennaRetPct", pct(Mm["benna_fusi"]["retention_mean"]))
macro("ReplayRetPct", pct(Mm["replay"]["retention_mean"]))
macro("NaiveRetPct", pct(Mm["none"]["retention_mean"]))
# honest framing: rehearsal-FREE consolidation methods (store no data) vs replay.
REHEARSAL_FREE = ["ou", "mesu", "ewc_best", "benna_fusi", "none"]
best_rf = max(REHEARSAL_FREE, key=lambda k: Mm[k]["retention_mean"])
macro("BestRFName", BASELINE_LABELS.get(best_rf, best_rf))
macro("BestRFRetPct", pct(Mm[best_rf]["retention_mean"]))
macro("BestRFP", num(Mm[best_rf]["wilcoxon_vs_doob_p"], 2))
macro("OursMinusRFPts", pts(Mm["doob*"]["retention_mean"] - Mm[best_rf]["retention_mean"]))
# the anchored methods ours SIGNIFICANTLY beats: report the worst (largest) p among them
_beaten = [Mm[k]["wilcoxon_vs_doob_p"] for k in REHEARSAL_FREE
           if k != best_rf and Mm[k]["wilcoxon_vs_doob_p"] < 0.05]
macro("AnchoredMaxP", num(max(_beaten), 3) if _beaten else "n/a")
# replay stores data and does better -> reported honestly, not as a loss we hide
macro("ReplayMinusOursPts", pts(Mm["replay"]["retention_mean"] - Mm["doob*"]["retention_mean"]))
macro("ReplayBuffer", str(e3["config"]["replay_buffer"]))
macro("NoiseTaxPct", pct(Mm["doob*"]["noise_tax_gpu"], 0))
# the noise-tax is NOT robust to the assumed per-op energies: report its span as
# the MAC-energy constant varies (noise_tax = noise_ops / (fwd/bwd MACs + consol))
from doobsyn import energy as _en
_np, _sig = e3["config"]["n_params"], e3["config"]["sigma_star"]
_fb = _en.forward_backward_macs(_np)
_con, _con0 = _en.consolidation_cost("doob", _np, _sig), _en.consolidation_cost("doob", _np, 0.0)
_noiseE = ((_con.adds - _con0.adds) * _en.E_ADD_PJ + (_con.rng - _con0.rng) * _en.E_RNG_PJ)
_conE = _con.adds * _en.E_ADD_PJ + _con.rng * _en.E_RNG_PJ + _con.tanh * _en.E_TANH_PJ
_taxes = [_noiseE / (_fb * emac + _conE) for emac in (0.5, 1.0, 3.1, 10.0, 30.0)]
macro("NoiseTaxLoPct", pct(min(_taxes), 0))
macro("NoiseTaxHiPct", pct(max(_taxes), 0))
macro("CapBindPct", pct(load("clamp_frac.json")["clamp_frac_mean"], 1))

# ------------------------------------------------------------------ E4 modality
yy = e4["yin_yang"]["doob"]["inverted_u"]
macro("YYLiftPts", pts(yy["lift_over_zero"]))
macro("YYSigStar", g(yy["sigma_star"]))
macro("YYSurviveWord", "reproduces" if yy["inverted_u"] else "does not reproduce")

# ------------------------------------------------------------------ E5 on-silicon
try:
    sil = load("bss2_silicon_noise.json")
    e5 = load("exp5_silicon.json")
    fit = e5["silicon_fit"]
    macro("SiliconChip", sil["chip"].replace("_", "\\_"))
    macro("SiliconAdditivePct", pct(fit["additive_frac_at_median"]))
    macro("SiliconMultPct", pct(fit["mult_frac_at_median"]))
    macro("SiliconCVMaxPct", pct(fit["cv_max"]))
    macro("SiliconCVMinPct", pct(fit["cv_min"]))
    macro("SiliconNumSendsExp", num(fit["num_sends_exponent"], 2))
    macro("SiliconTrialStd", num(fit["trial_std_mean"], 2))
    _ssig = sil["noise_vs_signal"]["signal"]
    macro("SiliconSignalRange", num(max(_ssig) / min(_ssig), 1) + "\\times")
    macro("SiliconNumSendsPts", str(len(sil["noise_vs_num_sends"]["num_sends"])))
    macro("SiliconRepeats", str(sil.get("config", {}).get("R", 128)))
    siu = e5["measured_noise_sweep"]["inverted_u"]
    macro("SiliconMeasLiftPts", pts(siu["lift_over_zero"]))
    macro("SiliconMeasSigStar", g(siu["sigma_star"]))
    macro("SiliconMeasWord", "survives" if siu["inverted_u"] else "does not survive")
except FileNotFoundError:
    pass

# ------------------------------------------------------------------ E6 forward realization
try:
    e6 = load("exp6_forward.json")
    fd = e6["forward"]["doob"]["inverted_u"]
    fo = e6["forward"]["ou"]["inverted_u"]
    macro("FwdDoobLiftPts", pts(fd["lift_over_zero"]))
    macro("FwdDoobSigStar", g(fd["sigma_star"]))
    macro("FwdDoobP", num(fd["p_peak_gt_zero"], 3))
    macro("FwdDoobWord", "an inverted-U" if fd["inverted_u"] else "monotone")
    macro("FwdOuLiftPts", pts(fo["lift_over_zero"]))
    macro("FwdNoclampRet", num(e6["clamp_ablation"]["noclamp"]["retention_mean"][0], 3))
    macro("FwdClampRetPeak", num(max(e6["clamp_ablation"]["clamp"]["retention_mean"]), 3))
    cs = e6["coupling_scan"]
    macro("FwdMinSigStar", g(min(cs[k]["sigma_star"] for k in cs)))
    kbest = max(cs, key=lambda k: cs[k]["lift"])
    macro("FwdBestCoupling", g(float(kbest)))
    macro("FwdBestCouplingLiftPts", pts(cs[kbest]["lift"]))
    macro("FwdBestCouplingSigStar", g(cs[kbest]["sigma_star"]))
except FileNotFoundError:
    pass

# ------------------------------------------------------------------ E7 on-silicon training
try:
    st = load("bss2_silicon_training.json")
    macro("SilTrainDoobRet", pct(st["doob"]["task0_retention"]))
    macro("SilTrainOuRet", pct(st["ou"]["task0_retention"]))
    macro("SilTrainDoobTaskOne", pct(st["doob"]["task1_acc"]))
    macro("SilTrainOuTaskOne", pct(st["ou"]["task1_acc"]))
    macro("SilTrainRetGainPts", pts(st["retention_doob_minus_ou"]))
    macro("SilTrainDoobAvgPct", pct((st["doob"]["task0_retention"] + st["doob"]["task1_acc"]) / 2))
    macro("SilTrainOuAvgPct", pct((st["ou"]["task0_retention"] + st["ou"]["task1_acc"]) / 2))
    macro("SilTrainWallMin", num(st["config"]["wall_s"] / 60.0, 0))
except FileNotFoundError:
    pass

# ------------------------------------------------------------------ emit
lines = [f"\\newcommand{{\\{k}}}{{{v}}}" for k, v in sorted(M.items())]
OUT.write_text("\n".join(lines) + "\n")
print(f"[wrote] {OUT}  ({len(M)} macros)")
