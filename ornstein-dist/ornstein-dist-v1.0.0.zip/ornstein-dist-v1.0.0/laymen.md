# What We Did, In Plain English

*A no-math explanation of this project and the paper that came out of it.*

---

## The problem, starting from zero

Scientists increasingly use AI to imitate complicated physical systems — weather,
climate, turbulent fluids, and so on. Instead of running a slow, expensive
physics simulation, you train an AI "stand-in" (the technical word is
**surrogate**) that behaves like the real thing but runs much faster.

Here's the catch: these systems are **chaotic**. Chaos means tiny differences
snowball. Two weather simulations that start almost identically will look
completely different a couple of weeks in — that's the famous "butterfly
effect," and it's not a flaw, it's just what these systems do.

That creates a weird grading problem. You can't grade an AI stand-in by asking
"did it predict the exact same future as the real system?" — because even a
*perfect* copy of the real system would fail that test. Perfection doesn't look
like matching; matching is impossible past a short horizon.

## How people grade these AIs today — and the hole in it

So the field settled on a sensible-sounding fix: don't compare the exact
predictions, compare the **overall habits**. Run both systems for a long time
and check: do they visit the same places, in the same proportions? Think of it
like a long-exposure photograph — leave the camera shutter open for hours, and
you get a glowing picture of everywhere the system spends its time.

If the AI's long-exposure photo matches the real one, the AI is declared good.

Here's our starting observation: **a photo is not a movie.** A long-exposure
photo of a dancer tells you where on the stage she spent her time. It tells you
*nothing* about the dance — how fast she moved, in what order, with what rhythm.
Two completely different dances can leave the *exact same* photo.

The same is true for these physical systems. And that means the field's
standard report card has a blind spot: an AI can ace the photo test while
getting the actual *motion* — the dance — completely wrong.

## What we did

### 1. We found the right measuring tool in an unexpected place

Fifty years ago, mathematicians studying a very abstract question ("when are
two random processes secretly the same process?") invented a way of measuring
the distance between two *movies* rather than two photos. It's called
**Ornstein's d-bar distance**. It has beautiful theory behind it, but nobody
had ever used it to grade AI models of chaotic systems. We took it off the
shelf, dusted it off, and turned it into a practical tool.

The intuition: imagine playing the two movies side by side, and you're allowed
to line them up as cleverly as you possibly can. The d-bar distance asks:
*even with the best possible alignment, what fraction of the time do they
still disagree?* If two systems dance the same dance, you can sync them almost
perfectly. If the dances are truly different, no amount of clever syncing
helps — and the tool tells you so.

### 2. We made it actually computable

The pure math version is impossible to compute directly. Our recipe:

- **Simplify the signal.** Instead of tracking exact numbers, record a simple
  stream of letters — for the famous "butterfly" system we studied, literally
  just which wing of the butterfly the system is on: left, left, right, left...
- **Compare the phrases.** Chop both letter streams into short phrases (2
  letters, 4, 8, 16...) and ask how differently the two systems "speak" —
  do they use the same phrases with the same frequencies?
- **Build in a lie detector.** Any measurement on finite data has noise. So we
  always run the same comparison on *two recordings of the identical system* —
  which should show zero difference — and report that alongside. If our
  "difference" isn't clearly bigger than that baseline, we don't count it.
  Our tool is honest about its own limits by construction.
- **Add an independent second opinion.** A classic theorem lets us certify a
  minimum distance using a completely different calculation (based on how
  "surprising" each system's behavior is, moment to moment). When both methods
  agree, you can trust the answer.

### 3. We built counterfeits designed to fool the photo test — and caught them

This was the heart of the project. We manufactured fake systems that are
*mathematically guaranteed* to pass the photo test:

- **The remix.** A doctored version of the real signal that keeps the exact
  same distribution of values and the same rhythm content, but scrambles the
  actual dynamics. (A standard trick from signal processing.)
- **The fast-forward.** The real system played at 2x speed. Same photo,
  *exactly* — every place gets visited in the same proportions — but obviously
  a different dance.

The photo test scored both counterfeits as **flawless**. Our test flagged both
at **enormous confidence** — the measured difference was up to fifty times
larger than the noise baseline. And on genuine copies of the real system, our
test correctly reported "no difference." We repeated everything eight times
with fresh data to make sure none of it was luck, and it held on a second,
much more complex system (a model of flame-front turbulence) too.

### 4. We tested it on a real AI, not just counterfeits

We trained a family of small AI models to imitate the butterfly system. Most
learned it well — and importantly, our test *agreed* they were good (a smoke
alarm that goes off during every shower is useless). Then we deliberately
handicapped one model in a subtle, realistic way. The result was the whole
point of the project in one example: the handicapped AI **still passed the
photo test**, but its dance was wrong — and our test caught it clearly.

### 5. We were honest about what it can't do

One counterfeit slipped past: the real system **played backwards**. Playing a
movie in reverse keeps the photo, the rhythm content, *and* the
surprise-per-second identical — it's the deepest possible fake — and at the
resolution we used, our tool couldn't see it either (we explain exactly why in
the paper, and what it would take to catch it). Real science reports its
misses. This is ours, stated plainly, along with the tool's other limits.

## What we accomplished, in one sentence

**We gave the field a practical, honest way to check whether an AI imitation
of a chaotic system gets the *motion* right, not just the *map* — and showed
that the standard test misses exactly this, while ours catches it.**

## Why this matters

- **Better report cards for science AI.** AI emulators of weather, climate, and
  fluids are being deployed now. Decisions get made on their output. A model
  that hangs out in all the right places but moves wrongly will get event
  *timing*, *persistence*, and *variability* wrong — think how long a heat wave
  lasts, how quickly storms follow each other. Today's standard evaluation
  cannot see that failure. Ours can.
- **Trust through honesty.** Every number our tool reports comes with a
  built-in noise baseline and, where possible, an independent certificate.
  You know not just the answer but how much to believe it.
- **Cheap.** No supercomputer needed — everything in the paper runs on an
  ordinary desktop CPU in minutes, and the method works with surprisingly
  little data.
- **A path to better AI, not just better grading.** The natural next step is
  to use this measurement *during training*, so models are directly rewarded
  for getting the dynamics right — not just the long-exposure photo. That
  could produce a next generation of science AIs that are faithful in a
  deeper sense than today's.
- **A bridge between fields.** A profound 50-year-old body of pure mathematics
  turns out to answer a very current AI question. We suspect there's more
  where that came from.

## Where everything lives

- The full technical story: `paper/main.pdf`
- The verified math notes: `docs/RESEARCH_NOTES.md`
- The code and every raw result: this repository (see `README.md` to reproduce
  everything with a few commands)
